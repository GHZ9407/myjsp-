package com.example.music;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import static com.example.music.PermisionUtils.verifyStoragePermissions;

public class MainActivity extends AppCompatActivity {
    public static final int FILE_RESULT_CODE = 1;

    private String musicpath;
    private ArrayList<HashMap<String, String>> musicList;
    private ArrayList<String> musicPathList;
    private ArrayList<String> musicHistoryList;
    private ArrayList<String> musicHistoryAllList;
    private ListView lv;
    private FloatingActionButton floatingActionButton;
    private FloatingActionButton floatingActionButton1;
    private String musicPath = "/mnt/sdcard/netease/cloudmusic/Music/";
    private String musicName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingActionButton1 = findViewById(R.id.song_find);
        floatingActionButton1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,MyFileManager.class);
                startActivityForResult(intent, FILE_RESULT_CODE);
            }
        });
        musicPathList = new ArrayList<>();
        musicList = new ArrayList<>();
        musicHistoryList = new ArrayList<>();
        musicHistoryAllList = new ArrayList<>();

        lv = findViewById(R.id.listMode);
        floatingActionButton = findViewById(R.id.song_history);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent();
//                musicHistoryList = intent.getStringArrayListExtra("musicHistoryList");
//                System.out.println(musicHistoryList + "/////111///");
                Intent intentToHistory = new Intent(MainActivity.this, HistoryActivity.class);
                intentToHistory.putStringArrayListExtra("musicHistoryAllList", musicHistoryAllList);
                startActivity(intentToHistory);
            }
        });
        Find();

//        for (int i = 0; i < musicList.size(); i++) {
//            Log.i(LOG.toString(), "list.  name:  " + musicList.get(i));
//        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(FILE_RESULT_CODE == requestCode){
            Bundle bundle = null;
            if(data!=null&&(bundle=data.getExtras())!=null){
                musicPath = bundle.getString("file");
                musicList.clear();
                musicPathList.clear();
                Find();
            }
        }

        if (requestCode == 2) {
            Bundle bundle = null;
            if (data != null&&(bundle=data.getExtras())!=null) {
                musicHistoryList = bundle.getStringArrayList("musicHistoryList");

                for (String index : musicHistoryList) {
                    musicHistoryAllList.add(index);
                }
//                System.out.println(musicHistoryList + "aaa222aaa222 "+ requestCode + resultCode);
//                System.out.println(musicHistoryAllList + "111111111111  "+ requestCode + resultCode);
            }
        }
    }

    private void Find() {
        verifyStoragePermissions(this);
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File path = new File(musicPath);// 获得SD卡路径
//            System.out.println("path-------》" + path.getPath());
            File[] files = path.listFiles();// 读取
            getFileName(files);  //列表
        }

        SimpleAdapter adapter = new SimpleAdapter(
                this,
                musicList,
                R.layout.list_item,
                new String[] {"name"},
                new int[] {
                        R.id.item_txt
                });
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new ListView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final TextView item_txt = findViewById(R.id.item_txt);
//                System.out.println("position" + parent.getItemAtPosition(position));
                HashMap<String, String> item = (HashMap) parent.getItemAtPosition(position);
                String item_name = item.get("name");
//                musicHistoryList.add(item_name);
                Intent intent = new Intent(MainActivity.this, MusicActivity.class);
//                System.out.println(item_name);
                intent.putExtra("item", item_name);
                intent.putExtra("position", position);
                intent.putExtra("musicPath", musicPath);
                intent.putStringArrayListExtra("musicList", musicPathList);
                startActivityForResult(intent, 2);

            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // must store the new intent unless getIntent() will return the old one
        setIntent(intent);
    }


        private void getFileName(File[] files) {
        //先判断目录是否为空，否则会报空指针
        if (files != null) {
            for (File file : files) {
                String fileName = file.getName();
//                System.out.println(fileName);
                if (fileName.endsWith(".mp3")) {
                    HashMap<String, String> map = new HashMap<String, String>();
                    String s = fileName.substring(0,fileName.lastIndexOf(".")).toString();
                    //获取文件的地址
                    musicpath = file.getPath();
//                    System.out.println(musicpath + "+++++++++++++");
//                    System.out.println(s + "--------");
                    map.put("name", fileName);
                    // map.put("mp3", f.getName());
                    musicPathList.add(fileName);
                    musicList.add(map);
                }
            }
        }
    }
}

